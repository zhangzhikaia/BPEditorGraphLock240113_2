// Copyright lurongjiu. All Rights Reserved.


#include "EdGraphNode_Lock.h"

#include "DebugHeader.h"
#include "SNodeStyle_Lock.h"
#include "Engine/World.h"
#include "BlueprintUtilities.h"
#include "BPEditorGraphLock.h"
#include "Internationalization/Text.h"
#include "Templates/SharedPointer.h"
#include "Templates/UnrealTemplate.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/SCompoundWidget.h"
#include "IconStyleSet.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/SNullWidget.h"

UEdGraphNode_Lock::UEdGraphNode_Lock()
{
	IsOnActiveTabChangedBinded = false;
}

UEdGraphNode_Lock::~UEdGraphNode_Lock()
{
	/*When the blueprint compiles, it will call a ~UEdGraphNode_Lock(), but it does not deregister the Handle.
	 *When the blueprint is deleted, it will call the destructor and actually deregister the ActiveTabChangedHandle.*/
	FGlobalTabmanager::Get()->OnActiveTabChanged_Unsubscribe(ActiveTabChangedHandle);
}

TSharedPtr<SGraphNode> UEdGraphNode_Lock::CreateVisualWidget()
{
	return SNew(SNodeStyle_Lock, this);
}

void UEdGraphNode_Lock::OnActiveTabChangedBindOnce()
{
	if(IsOnActiveTabChangedBinded == true) return;
	ActiveTabChangedHandle = FGlobalTabmanager::Get()->OnActiveTabChanged_Subscribe(FOnActiveTabChanged::FDelegate::CreateLambda(
	[this](TSharedPtr<SDockTab> PreviouslyTab, TSharedPtr<SDockTab> NewlyTab)
	{
		const FString NewlyTabName = NewlyTab->GetTabLabel().ToString();
		
		if(TSharedPtr<SGraphEditor> GraphEditor = StaticCastSharedRef<SGraphEditor>(NewlyTab->GetContent()))
        {
        	if (GraphEditor.IsValid() && GraphEditor != nullptr)
            {
        		if(this->GetGraph() == GraphEditor->GetCurrentGraph())
        		{
        			ConstructButton(GraphEditor);
        		}
        		else if(NewlyTabName.StartsWith(TEXT("New Function"),ESearchCase::CaseSensitive)
        			 || NewlyTabName.StartsWith(TEXT("New Macro"),ESearchCase::CaseSensitive)
        			 || NewlyTabName.StartsWith(TEXT("New Event Graph"),ESearchCase::CaseSensitive))
        		{
        			FBPEditorGraphLockModule& BPEditorGraphLockModule =
					FModuleManager::LoadModuleChecked<FBPEditorGraphLockModule>(TEXT("BPEditorGraphLock"));
        			
					BPEditorGraphLockModule.AddUEdGraphNode_Lock(GraphEditor->GetCurrentGraph());
        		}
            }
        }
	}));
	IsOnActiveTabChangedBinded = true;
}

void UEdGraphNode_Lock::ConstructButton(TSharedPtr<SGraphEditor> GraphEditor)
{
	TitleScrollBox = ((HackSGraphTitleBar*)GraphEditor->GetTitleBar().Get())->GetBreadcrumbTrailScrollBox();
	
	if(TitleScrollBox.IsValid())
	{
		const FCheckBoxStyle* CheckBoxStyle =
		&FIconStyleSet::CreatedSlateStyleSet->GetWidgetStyle<FCheckBoxStyle>(FName("IsGraphLocked"));
		
		if(LockCheckBox!=nullptr&&LockCheckBox.IsValid())
		{
			TitleScrollBox->RemoveSlot(LockCheckBox.ToSharedRef());
		}
		
		TitleScrollBox->AddSlot()
		.AutoSize()
		.Padding(0.f)
		.VAlign(VAlign_Center)
		[
			SAssignNew(LockCheckBox,SCheckBox)
			//.Type(ESlateCheckBoxType::ToggleButton)
			.Style(CheckBoxStyle)
			.IsChecked(this->GetGraph()->bEditable?ECheckBoxState::Checked:ECheckBoxState::Unchecked)
			.OnCheckStateChanged_Lambda([&](ECheckBoxState CheckBoxState)
			{
				switch (CheckBoxState)
				{
				case ECheckBoxState::Checked:
					this->GetGraph()->bEditable = true;
					TitleScrollBox->ScrollToEnd();
					break;
				case ECheckBoxState::Unchecked:
					this->GetGraph()->bEditable = false;
					TitleScrollBox->ScrollToEnd();
					break;
				case ECheckBoxState::Undetermined:
					break;
					default:break;
				}
			})
		];
		TitleScrollBox->ScrollToEnd();
	}
}

