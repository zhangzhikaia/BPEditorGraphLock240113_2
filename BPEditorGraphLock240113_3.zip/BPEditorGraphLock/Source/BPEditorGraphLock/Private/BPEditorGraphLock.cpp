// Copyright lurongjiu. All Rights Reserved.

#include "BPEditorGraphLock.h"

#include "GraphEditor.h"
#include "BlueprintEditorModule.h"
#include "BlueprintEditor.h"
#include "DebugHeader.h"
#include "IconStyleSet.h"
#include "EdGraph/EdGraphNode.h"
#include "LockNode/EdGraphNode_Lock.h"

#define LOCTEXT_NAMESPACE "FBPEditorGraphLockModule"

void FBPEditorGraphLockModule::StartupModule()
{
	/*Register icons*/
	FIconStyleSet::InitializeIcons();
	
	/*Register GraphTitlebar extender*/
	InitBPEditorExtender();
}

void FBPEditorGraphLockModule::ShutdownModule()
{
	/*Unregister icons*/
	FIconStyleSet::ShutDownIcons();
	
	/*Unregister GraphTitlebar extender*/
	FinishBPEditorExtender();
}

void FBPEditorGraphLockModule::InitBPEditorExtender()
{
	FBlueprintEditorModule& BlueprintEditorModule =
		FModuleManager::LoadModuleChecked<FBlueprintEditorModule>(TEXT("Kismet"));

	OnRegisterTabsForEditorHandle =
		BlueprintEditorModule.OnRegisterTabsForEditor().AddRaw(this, &FBPEditorGraphLockModule::HandleRegisterBlueprintEditorTab);
}

void FBPEditorGraphLockModule::FinishBPEditorExtender()
{
	FBlueprintEditorModule& BlueprintEditorModule =
		FModuleManager::LoadModuleChecked<FBlueprintEditorModule>(TEXT("Kismet"));
	
	BlueprintEditorModule.OnRegisterTabsForEditor().Remove(OnRegisterTabsForEditorHandle);
}

void FBPEditorGraphLockModule::HandleRegisterBlueprintEditorTab(FWorkflowAllowedTabSet& WorkflowAllowedTabSet,FName ModeName, TSharedPtr<FBlueprintEditor> BlueprintEditor)
{
	if(BlueprintEditor.IsValid())
	{
		TArray<UEdGraph*> Graphs;
        BlueprintEditor->GetBlueprintObj()->GetAllGraphs(Graphs);
        if(!Graphs.IsEmpty())
        {
        	for(UEdGraph* Graph : Graphs)
        	{
        		AddUEdGraphNode_Lock(Graph);
        	}
        }
	}
}

void FBPEditorGraphLockModule::AddUEdGraphNode_Lock(UEdGraph* Graph)
{
	TArray<UEdGraphNode_Lock*> OutNodes;
	Graph->GetNodesOfClass<UEdGraphNode_Lock>(OutNodes);
	if(OutNodes.IsEmpty())
	{
		UEdGraph& NowGraph = *Graph;
		FGraphNodeCreator<UEdGraphNode_Lock> NodeCreator(NowGraph);
		UEdGraphNode_Lock* NewNode = NodeCreator.CreateNode(false);
		NewNode->OnActiveTabChangedBindOnce();
		NodeCreator.Finalize();
	}
	else
	{
		OutNodes[0]->OnActiveTabChangedBindOnce();
		
		/*There should be no such possibility,measure for safety*/
		if (OutNodes.Num()>1) 
		{
			OutNodes.RemoveAt(0);
			for (UEdGraphNode_Lock* NodeToDestroy : OutNodes)
			{
				NodeToDestroy->DestroyNode();
			}
		}
	}
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FBPEditorGraphLockModule, BPEditorGraphLock)