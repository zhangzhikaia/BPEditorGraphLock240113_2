// Copyright lurongjiu. All Rights Reserved.

using UnrealBuildTool;

public class BPEditorGraphLock : ModuleRules
{
	public BPEditorGraphLock(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
		
		PublicIncludePaths.AddRange(
			new string[] {
			
			}
			);
				
		
		PrivateIncludePaths.AddRange(
			new string[] {
				System.IO.Path.GetFullPath(Target.RelativeEnginePath) + "/Source/Editor/Kismet/Private",
			
			}
			);
			
		
		PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				"Kismet",
				"UnrealEd",
				"GraphEditor",
				"KismetWidgets",
				"Documentation",
				"Projects",
				"Slate",
				
			}
			);
			
		
		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"CoreUObject",
				"Engine",
				"Slate",
				"SlateCore",
				"KismetWidgets",
				"GraphEditor",
				"InputCore",
				"Kismet",
				
			}
			);
		
		
		DynamicallyLoadedModuleNames.AddRange(
			new string[]
			{
				
			}
			);
		
	}
}
